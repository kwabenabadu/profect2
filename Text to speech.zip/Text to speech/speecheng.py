import pyttsx3 

class Speech_eng:
    def Voice_type(input_type, voice_type, speed_rate, volume):
        speaker = pyttsx3.init()
        voices = speaker.getProperty('voices')
        speaker.setProperty('voice', voices[voice_type].id)
        speaker.setProperty('rate', speed_rate)
        speaker.setProperty('volume', volume)
        speaker.say(input_type)
        speaker.runAndWait()
    
        