import PySimpleGUI as sg
from speecheng import Speech_eng


sg.theme_background_color('#635985')
layout = [
   [sg.Multiline(key = 'Text_input', font=('Open Sans', 12), size=(40, 2)),
     sg.Button('Speak', key = 'Speak_button', font=('Open Sans', 12), button_color='#00235B')],
   [sg.Text('Select Voice Type',font=('Open Sans', 11), background_color= '#635985'), 
    sg.Radio('Male','Gender', key = 'Male_voice', default=True, font=('Open Sans', 11), background_color= '#635985'), 
    sg.Radio('Female', 'Gender', key = 'Female_voice', font=('Open Sans', 11), background_color= '#635985')],
   [sg.Text('Speech rate', font=('Open Sans', 11), background_color= '#635985'), sg.Input(key='speed_rate', size=3, default_text='150', font=('Open Sans', 11))],
   [sg.Text('Volume level', font=('Open Sans', 11),background_color= '#635985'), 
    sg.Slider(key = 'volume', range=(0, 10), orientation='horizontal', size=(10, 15), default_value= 5, font=('Open Sans', 11), background_color= '#635985')]
]   

window = sg.Window('Text to Speach App', layout)

while True:
    event, values = window.read()
    if event == sg.WIN_CLOSED:
        break

    input = values['Text_input']
    speed_r = int(values['speed_rate']) 
    speech_vol = int(values['volume']) * 0.1

    if event =='Speak_button':
        if values['Male_voice'] == True:
            Speech_eng.Voice_type(input_type=input,voice_type=0,speed_rate=speed_r,volume=speech_vol)
        
        if values['Female_voice'] == True:
            Speech_eng.Voice_type(input_type=input,voice_type=1,speed_rate=speed_r,volume=speech_vol )
        
window.close()  
   

